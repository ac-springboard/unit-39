import React from "react";
import Counter from "./Counter";

function App() {
  return (
    <div>
      Hello, I'm an App!
      <Counter />
    </div>
  );
}

export default App;
